import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// CORS headers for all requests
app.use((_req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range');
  next();
});

// Proxy endpoints for course content and video details with fallback
app.get('/get/folder_contentsv3', async (req: Request, res: Response) => {
  const { course_id, parent_id = '-1', start = '0' } = req.query;
  const targetUrl = `https://scienceandfun.studybeepro.site/get/folder_contentsv3?course_id=${course_id}&parent_id=${parent_id}&start=${start}`;
  try {
    const upstreamRes = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    const data = await upstreamRes.json();
    res.json(data);
  } catch (error: any) {
    console.error('Error proxying folder contents:', error.message);
    res.status(502).json({ success: false, message: error.message, data: [] });
  }
});

app.get('/get/fetchVideoDetailsById', async (req: Request, res: Response) => {
  const { course_id, video_id } = req.query;
  const targetUrl = `https://scienceandfun.studybeepro.site/get/fetchVideoDetailsById?course_id=${course_id}&video_id=${video_id}`;
  try {
    const upstreamRes = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    const data = await upstreamRes.json();
    res.json(data);
  } catch (error: any) {
    console.error('Error proxying video details:', error.message);
    res.status(502).json({ success: false, message: error.message });
  }
});

// Video Stream Proxy (HLS m3u8 and ts chunks)
app.get('/video', async (req: Request, res: Response) => {
  const rawUrl = req.query.url as string;
  if (!rawUrl) return res.status(400).send('No video URL provided');

  const proxyTarget = `https://scienceandfun.studybeepro.site/video?url=${encodeURIComponent(rawUrl)}`;
  try {
    const upstreamRes = await fetch(proxyTarget, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://scienceandfun.studybeepro.site/'
      }
    });

    const contentType = upstreamRes.headers.get('content-type') || 'application/vnd.apple.mpegurl';
    res.setHeader('Content-Type', contentType);
    
    // Pipe response
    const arrayBuf = await upstreamRes.arrayBuffer();
    res.send(Buffer.from(arrayBuf));
  } catch (err: any) {
    console.warn('Video proxy error, redirecting directly:', err.message);
    res.redirect(rawUrl);
  }
});

// MPD Stream Proxy
app.get('/mpd', async (req: Request, res: Response) => {
  const rawUrl = req.query.url as string;
  if (!rawUrl) return res.status(400).send('No MPD URL provided');

  const proxyTarget = `https://scienceandfun.studybeepro.site/mpd?url=${encodeURIComponent(rawUrl)}`;
  try {
    const upstreamRes = await fetch(proxyTarget, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://scienceandfun.studybeepro.site/'
      }
    });
    const contentType = upstreamRes.headers.get('content-type') || 'application/dash+xml';
    res.setHeader('Content-Type', contentType);
    const arrayBuf = await upstreamRes.arrayBuffer();
    res.send(Buffer.from(arrayBuf));
  } catch (err: any) {
    res.redirect(rawUrl);
  }
});

// PDF Proxy with inline streaming
app.get('/pdf', async (req: Request, res: Response) => {
  const targetUrl = req.query.url as string;
  if (!targetUrl) return res.status(400).send('No PDF URL provided');

  try {
    const upstream = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (upstream.ok) {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'inline');
      const buffer = await upstream.arrayBuffer();
      return res.send(Buffer.from(buffer));
    }
  } catch (err) {}
  
  // fallback redirect
  res.redirect(targetUrl);
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
