export interface Batch {
  id: number | string;
  title: string;
  thumbnail: string;
  category?: string;
  classTag?: string;
  isLive?: boolean;
  year?: string;
}

export interface FolderItem {
  id: string;
  parent_id: string;
  Title: string;
  title?: string;
  description?: string;
  material_type: 'FOLDER' | 'VIDEO' | 'PDF' | 'NOTES' | 'TEST' | string;
  type?: string;
  thumbnail?: string;
  date_and_time?: string;
  event_date?: string;
  duration?: string;
  duration_in_secs?: string;
  file_link?: string;
  pdf_link?: string;
  download_link?: string;
  videos_count?: string | number;
  files_count?: string | number;
  tests_count?: string | number;
  course_id?: string;
  live_status?: number | string;
  livestream_links?: any[];
}

export interface VideoQuality {
  quality: string;
  url: string;
}

export interface VideoDetails {
  success: boolean;
  video_id: string;
  course_id: string;
  title: string;
  duration?: string;
  thumbnail?: string;
  date?: string;
  decoded_video_link?: string;
  player_url?: string;
  qualities?: VideoQuality[];
  error?: string;
}

export interface BreadcrumbCrumb {
  id: string;
  title: string;
}
