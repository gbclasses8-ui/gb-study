import { Batch, FolderItem, VideoDetails } from '../types';
import rawBatches from '../data/batches.json';
import localFolderCache from '../data/batchFoldersCache.json';

// Type assertion for local cache
const folderCacheMap = localFolderCache as Record<string, FolderItem[]>;

// Helper to classify batches
function classifyBatch(b: { id: number | string; title: string; thumbnail: string }): Batch {
  const title = b.title.toLowerCase();
  let classTag = 'Other';
  if (title.includes('class 12') || title.includes('12th')) classTag = 'Class 12th';
  else if (title.includes('class 11') || title.includes('11th')) classTag = 'Class 11th';
  else if (title.includes('class 10') || title.includes('10th')) classTag = 'Class 10th';
  else if (title.includes('class 9') || title.includes('9th')) classTag = 'Class 9th';
  else if (title.includes('nda') || title.includes('tejas') || title.includes('udaan')) classTag = 'NDA & Defence';
  else if (title.includes('ca foundation') || title.includes('buniyaad')) classTag = 'CA Foundation';
  else if (title.includes('cuet')) classTag = 'CUET';
  else if (title.includes('jee') || title.includes('neet')) classTag = 'JEE / NEET';

  const isLive = title.includes('live');

  return {
    id: b.id,
    title: b.title,
    thumbnail: b.thumbnail,
    classTag,
    isLive,
    category: title.includes('science') ? 'Science' : title.includes('commerce') ? 'Commerce' : 'General'
  };
}

export const ALL_BATCHES: Batch[] = (rawBatches.new || []).map(classifyBatch);

export async function getBatches(): Promise<Batch[]> {
  try {
    const res = await fetch('batches.json');
    if (res.ok) {
      const data = await res.json();
      const list = [...(data.new || []), ...(data.old || [])];
      if (list.length > 0) {
        return list.map(classifyBatch);
      }
    }
  } catch {
    // fallback to statically bundled batches
  }
  return ALL_BATCHES;
}

export async function fetchFolderContents(courseId: string, parentId: string = '-1'): Promise<FolderItem[]> {
  const cacheKey = `${courseId}_${parentId}`;
  
  // 1. Try local proxy/server endpoint first
  try {
    const res = await fetch(`/get/folder_contentsv3?course_id=${courseId}&parent_id=${parentId}&start=0`);
    if (res.ok) {
      const json = await res.json();
      if (json && Array.isArray(json.data) && json.data.length > 0) {
        return json.data;
      }
    }
  } catch (err) {
    console.warn('Proxy fetch failed, trying fallbacks', err);
  }

  // 2. Check pre-cached folder structure
  if (folderCacheMap[cacheKey] && folderCacheMap[cacheKey].length > 0) {
    return folderCacheMap[cacheKey];
  }

  // 3. Fallback direct remote fetch
  try {
    const remoteRes = await fetch(`https://scienceandfun.studybeepro.site/get/folder_contentsv3?course_id=${courseId}&parent_id=${parentId}&start=0`);
    if (remoteRes.ok) {
      const json = await remoteRes.json();
      if (json && Array.isArray(json.data)) {
        return json.data;
      }
    }
  } catch (err) {
    console.warn('Direct remote fetch failed', err);
  }

  // Return empty list if nothing found
  return folderCacheMap[cacheKey] || [];
}

export async function fetchVideoDetails(courseId: string, videoId: string): Promise<VideoDetails> {
  // 1. Try proxy
  try {
    const res = await fetch(`/get/fetchVideoDetailsById?course_id=${courseId}&video_id=${videoId}`);
    if (res.ok) {
      const json = await res.json();
      if (json && (json.success || json.decoded_video_link || json.player_url)) {
        return json;
      }
    }
  } catch (err) {
    console.warn('Proxy video fetch failed, trying direct', err);
  }

  // 2. Try direct remote
  try {
    const remoteRes = await fetch(`https://scienceandfun.studybeepro.site/get/fetchVideoDetailsById?course_id=${courseId}&video_id=${videoId}`);
    if (remoteRes.ok) {
      const json = await remoteRes.json();
      if (json && (json.success || json.decoded_video_link || json.player_url)) {
        return json;
      }
    }
  } catch (err) {
    console.warn('Direct video details fetch failed', err);
  }

  throw new Error('Video details could not be loaded at this time. Please try again or join our Telegram for support.');
}

export function searchCachedLectures(query: string): Array<{ courseId: string; item: FolderItem }> {
  if (!query || query.trim().length < 2) return [];
  const q = query.toLowerCase();
  const results: Array<{ courseId: string; item: FolderItem }> = [];

  for (const [key, items] of Object.entries(folderCacheMap)) {
    const [courseId] = key.split('_');
    for (const item of items) {
      if (item.Title && item.Title.toLowerCase().includes(q)) {
        results.push({ courseId, item });
        if (results.length >= 25) return results;
      }
    }
  }
  return results;
}
