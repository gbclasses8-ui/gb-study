import React, { useState, useEffect } from 'react';
import { Batch, FolderItem } from './types';
import { getBatches, ALL_BATCHES } from './services/api';
import { Header } from './components/Header';
import { BatchCard } from './components/BatchCard';
import { BatchExplorer } from './components/BatchExplorer';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { PdfViewerModal } from './components/PdfViewerModal';
import { SearchModal } from './components/SearchModal';
import { TelegramModal, TELEGRAM_URL } from './components/TelegramModal';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { NotesSection } from './components/NotesSection';
import { 
  Sparkles, 
  Bookmark, 
  Search, 
  X, 
  ChevronDown, 
  GraduationCap, 
  Send, 
  ExternalLink,
  BookOpen,
  CheckCircle,
  FolderSearch
} from 'lucide-react';

const ENROLLED_STORAGE_KEY = 'gbstudy_enrolled_batches';
const TELEGRAM_POPUP_STORAGE_KEY = 'gbstudy_telegram_seen_v1';
const BATCHES_PER_PAGE = 12;

export default function App() {
  const [batches, setBatches] = useState<Batch[]>(ALL_BATCHES);
  const [loadingBatches, setLoadingBatches] = useState<boolean>(true);
  const [currentView, setCurrentView] = useState<'batches' | 'enrolled' | 'notes'>('batches');
  const [activeClassFilter, setActiveClassFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [visibleCount, setVisibleCount] = useState<number>(BATCHES_PER_PAGE);

  // Enrolled batch IDs (stored in localStorage)
  const [enrolledIds, setEnrolledIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(ENROLLED_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Active course navigation
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null);

  // Active Video Player Modal
  const [activeVideo, setActiveVideo] = useState<{
    item: FolderItem;
    allVideos: FolderItem[];
    courseId: string;
  } | null>(null);

  // Active PDF Viewer Modal
  const [activePdf, setActivePdf] = useState<{ title: string; url: string } | null>(null);

  // Global Search Modal
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);

  // Telegram Modal
  const [isTelegramOpen, setIsTelegramOpen] = useState<boolean>(false);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Fetch batches on mount
  useEffect(() => {
    async function loadData() {
      try {
        const list = await getBatches();
        if (list.length > 0) {
          setBatches(list);
        }
      } catch (err) {
        console.warn('Using bundled batches:', err);
      } finally {
        setLoadingBatches(false);
      }
    }
    loadData();
  }, []);

  // Show Telegram popup automatically on first visit with short delay
  useEffect(() => {
    const timer = setTimeout(() => {
      const hasSeen = sessionStorage.getItem(TELEGRAM_POPUP_STORAGE_KEY);
      if (!hasSeen) {
        setIsTelegramOpen(true);
        sessionStorage.setItem(TELEGRAM_POPUP_STORAGE_KEY, 'true');
      }
    }, 700);

    return () => clearTimeout(timer);
  }, []);

  // Save enrolled to localStorage
  const handleToggleEnroll = (id: string | number) => {
    const strId = String(id);
    setEnrolledIds(prev => {
      const exists = prev.includes(strId);
      const updated = exists ? prev.filter(i => i !== strId) : [...prev, strId];
      try {
        localStorage.setItem(ENROLLED_STORAGE_KEY, JSON.stringify(updated));
      } catch {}
      showToast(exists ? 'Batch removed from My Enrolled' : 'Batch added to My Enrolled! 🎉');
      return updated;
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Filtered batches computation
  const filteredBatches = batches.filter(batch => {
    const titleMatch = !searchQuery || 
      batch.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      String(batch.id).includes(searchQuery);

    if (!titleMatch) return false;

    if (currentView === 'enrolled') {
      return enrolledIds.includes(String(batch.id));
    }

    if (activeClassFilter === 'all') return true;
    return batch.classTag === activeClassFilter;
  });

  const displayedBatches = filteredBatches.slice(0, visibleCount);
  const hasMore = visibleCount < filteredBatches.length;

  const handleOpenBatch = (batch: Batch) => {
    setSelectedBatch(batch);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToBatches = () => {
    setSelectedBatch(null);
  };

  const handleSelectClassFilter = (tag: string) => {
    setSelectedBatch(null);
    setCurrentView('batches');
    setActiveClassFilter(tag);
    setVisibleCount(BATCHES_PER_PAGE);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filterTabs = [
    { label: 'All Batches', value: 'all' },
    { label: 'Class 12th', value: 'Class 12th' },
    { label: 'Class 11th', value: 'Class 11th' },
    { label: 'Class 10th', value: 'Class 10th' },
    { label: 'Class 9th', value: 'Class 9th' },
    { label: 'NDA & Defence', value: 'NDA & Defence' },
    { label: 'CA Foundation', value: 'CA Foundation' },
    { label: 'JEE / NEET', value: 'JEE / NEET' },
  ];

  return (
    <div className="min-h-screen flex flex-col gb-page-bg relative selection:bg-purple-500/30 selection:text-purple-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-full bg-[#180a29]/95 border border-purple-500/40 text-white text-xs sm:text-sm font-bold shadow-[0_10px_35px_rgba(168,85,247,0.4)] flex items-center gap-2.5 backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-300">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentView={currentView}
        onNavigate={(view) => {
          setSelectedBatch(null);
          setCurrentView(view);
          setVisibleCount(BATCHES_PER_PAGE);
        }}
        enrolledCount={enrolledIds.length}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenTelegram={() => setIsTelegramOpen(true)}
      />

      {/* Hero Announcement Banner */}
      {!selectedBatch && (
        <div className="w-full bg-gradient-to-r from-amber-950/40 via-purple-950/60 to-indigo-950/40 border-b border-amber-500/20 py-2.5 px-4 text-center">
          <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 sm:gap-3 text-xs sm:text-sm text-stone-200 flex-wrap">
            <span className="flex items-center gap-1.5 font-bold text-amber-300">
              <img src="/gb_logo.svg" alt="" className="w-4 h-4 object-contain" />
              Welcome to GB STUDY
            </span>
            <span className="hidden sm:inline text-amber-500/50">•</span>
            <span>All 46 Batches, HD Video Lectures & Notes 100% Free!</span>
            <a
              href={TELEGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-extrabold underline ml-1"
            >
              <span>Join @GBFreestudy</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 w-full relative z-10">
        {/* If a batch is open, show the Batch Explorer */}
        {selectedBatch ? (
          <BatchExplorer
            batch={selectedBatch}
            onBack={handleBackToBatches}
            isEnrolled={enrolledIds.includes(String(selectedBatch.id))}
            onToggleEnroll={handleToggleEnroll}
            onPlayVideo={(item, allVideos) => {
              setActiveVideo({
                item,
                allVideos,
                courseId: String(selectedBatch.id)
              });
            }}
            onOpenPdf={(title, url) => setActivePdf({ title, url })}
            onShowToast={showToast}
          />
        ) : currentView === 'notes' ? (
          /* Notes & PDF Library */
          <NotesSection
            batches={batches}
            onOpenPdf={(title, url) => setActivePdf({ title, url })}
            onOpenBatch={handleOpenBatch}
          />
        ) : (
          /* Batches / Enrolled Homepage */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 pb-20">
            {/* View Title & Top Filters */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-7">
              {/* Left tab buttons (Latest vs My Enrolled) */}
              <div className="flex items-center gap-2 p-1.5 bg-[#130a1c]/80 backdrop-blur-md rounded-2xl border border-white/10 shadow-inner w-full sm:w-auto overflow-x-auto no-scrollbar">
                <button
                  onClick={() => {
                    setCurrentView('batches');
                    setVisibleCount(BATCHES_PER_PAGE);
                  }}
                  className={`px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
                    currentView === 'batches'
                      ? 'bg-purple-600/30 text-white border border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>Latest Batches</span>
                  <span className="bg-purple-500/30 text-purple-200 px-2 py-0.5 rounded-md text-[10px] font-black border border-purple-500/20 ml-1">
                    {batches.length}
                  </span>
                </button>

                <button
                  onClick={() => {
                    setCurrentView('enrolled');
                    setVisibleCount(BATCHES_PER_PAGE);
                  }}
                  className={`px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 shrink-0 ${
                    currentView === 'enrolled'
                      ? 'bg-purple-600/30 text-white border border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                  <span>My Enrolled</span>
                  {enrolledIds.length > 0 && (
                    <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-black px-2 py-0.5 rounded-md ml-1">
                      {enrolledIds.length}
                    </span>
                  )}
                </button>
              </div>

              {/* Search Bar */}
              <div className="relative w-full md:w-80 group">
                <Search className="w-4.5 h-4.5 text-stone-500 group-focus-within:text-purple-400 absolute left-4 top-1/2 -translate-y-1/2 transition-colors" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setVisibleCount(BATCHES_PER_PAGE);
                  }}
                  placeholder="Search batches..."
                  className="w-full bg-[#130a1c]/90 border border-white/10 text-white text-xs sm:text-sm rounded-2xl pl-11 pr-10 py-3 focus:outline-none focus:border-purple-500/60 transition-all placeholder:text-stone-500 shadow-inner"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-500 hover:text-white p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Class & Category Filter Pills */}
            {currentView === 'batches' && (
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2 mb-8">
                {filterTabs.map((tab) => (
                  <button
                    key={tab.value}
                    onClick={() => {
                      setActiveClassFilter(tab.value);
                      setVisibleCount(BATCHES_PER_PAGE);
                    }}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                      activeClassFilter === tab.value
                        ? 'bg-purple-600 text-white shadow-md'
                        : 'bg-white/5 text-stone-400 hover:text-white border border-white/10'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            )}

            {/* Loading Skeletons */}
            {loadingBatches && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <div key={i} className="gb-card rounded-2xl overflow-hidden border border-white/5">
                    <div className="aspect-video gb-shimmer" />
                    <div className="p-5 space-y-3">
                      <div className="h-4 w-5/6 rounded gb-shimmer" />
                      <div className="h-3 w-2/3 rounded gb-shimmer" />
                      <div className="h-10 w-full rounded-xl gb-shimmer mt-4" />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Empty State */}
            {!loadingBatches && displayedBatches.length === 0 && (
              <div className="gb-card rounded-3xl p-12 text-center flex flex-col items-center justify-center max-w-md mx-auto my-12">
                <div className="w-16 h-16 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-4">
                  <FolderSearch className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">No Batches Found</h3>
                <p className="text-stone-400 text-xs sm:text-sm mb-6 max-w-xs">
                  {currentView === 'enrolled'
                    ? 'You have not enrolled in any batches yet. Browse Latest Batches and click the bookmark icon to save them!'
                    : 'No courses match your search criteria. Try clearing search or choosing another class category.'}
                </p>
                <button
                  onClick={() => {
                    setCurrentView('batches');
                    setActiveClassFilter('all');
                    setSearchQuery('');
                  }}
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md"
                >
                  View All Batches
                </button>
              </div>
            )}

            {/* Batches Grid */}
            {!loadingBatches && displayedBatches.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {displayedBatches.map((batch, index) => (
                  <BatchCard
                    key={batch.id}
                    batch={batch}
                    index={index}
                    isEnrolled={enrolledIds.includes(String(batch.id))}
                    onToggleEnroll={handleToggleEnroll}
                    onOpenBatch={handleOpenBatch}
                  />
                ))}
              </div>
            )}

            {/* Load More Button */}
            {!loadingBatches && hasMore && (
              <div className="w-full flex justify-center mt-12 mb-8">
                <button
                  onClick={() => setVisibleCount(prev => prev + BATCHES_PER_PAGE)}
                  className="px-8 py-3.5 bg-[#130a1c]/90 border border-purple-500/30 hover:border-purple-500 hover:bg-purple-600/10 rounded-2xl text-white font-bold text-xs sm:text-sm transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(168,85,247,0.15)] active:scale-95"
                >
                  <span>Load More Batches ({filteredBatches.length - visibleCount} remaining)</span>
                  <ChevronDown className="w-4 h-4 text-purple-400" />
                </button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenTelegram={() => setIsTelegramOpen(true)}
        onFilterClass={handleSelectClassFilter}
      />

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        currentView={currentView}
        onNavigate={(view) => {
          setSelectedBatch(null);
          setCurrentView(view);
          setVisibleCount(BATCHES_PER_PAGE);
        }}
        enrolledCount={enrolledIds.length}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Modals */}
      {/* 1. Telegram Modal */}
      <TelegramModal
        isOpen={isTelegramOpen}
        onClose={() => setIsTelegramOpen(false)}
      />

      {/* 2. Video Player Modal */}
      {activeVideo && (
        <VideoPlayerModal
          item={activeVideo.item}
          courseId={activeVideo.courseId}
          allVideos={activeVideo.allVideos}
          onClose={() => setActiveVideo(null)}
          onOpenPdf={(title, url) => setActivePdf({ title, url })}
          onSelectVideo={(newVideo) => {
            setActiveVideo(prev => prev ? { ...prev, item: newVideo } : null);
          }}
        />
      )}

      {/* 3. PDF Viewer Modal */}
      {activePdf && (
        <PdfViewerModal
          title={activePdf.title}
          pdfUrl={activePdf.url}
          onClose={() => setActivePdf(null)}
          onShowToast={showToast}
        />
      )}

      {/* 4. Global Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        batches={batches}
        onSelectBatch={(b) => {
          handleOpenBatch(b);
        }}
        onPlayVideo={(item, courseId) => {
          setActiveVideo({
            item,
            courseId,
            allVideos: [item]
          });
        }}
        onOpenPdf={(title, url) => setActivePdf({ title, url })}
      />
    </div>
  );
}
