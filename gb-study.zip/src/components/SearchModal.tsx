import React, { useState, useEffect, useRef } from 'react';
import { Batch, FolderItem } from '../types';
import { searchCachedLectures } from '../services/api';
import { Search, X, BookOpen, Play, FileText, ChevronRight, Layers } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  batches: Batch[];
  onSelectBatch: (batch: Batch) => void;
  onPlayVideo: (item: FolderItem, courseId: string) => void;
  onOpenPdf: (title: string, url: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  batches,
  onSelectBatch,
  onPlayVideo,
  onOpenPdf,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 80);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const trimmed = query.trim().toLowerCase();

  // Filter batches
  const matchedBatches = trimmed
    ? batches.filter(b => 
        b.title.toLowerCase().includes(trimmed) || 
        String(b.id).includes(trimmed) ||
        (b.classTag && b.classTag.toLowerCase().includes(trimmed))
      )
    : [];

  // Filter lectures/notes from indexed cache
  const matchedLectures = trimmed.length >= 2 ? searchCachedLectures(trimmed) : [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 pt-16 sm:pt-20 bg-black/80 backdrop-blur-md">
      <div className="gb-modal-glass w-full max-w-2xl rounded-3xl overflow-hidden flex flex-col max-h-[80vh] border border-purple-500/30 animate-in fade-in zoom-in-95">
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center gap-3 bg-black/30">
          <Search className="w-5 h-5 text-purple-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search batches, subjects, lectures, or PDFs..."
            className="flex-1 bg-transparent text-white placeholder-stone-500 text-sm sm:text-base outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-stone-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-stone-300 text-xs font-semibold"
          >
            Esc
          </button>
        </div>

        {/* Results Area */}
        <div className="overflow-y-auto p-4 sm:p-5 space-y-6">
          {!query && (
            <div className="py-8 text-center text-stone-400 text-xs sm:text-sm flex flex-col items-center">
              <img src="/gb_logo.svg" alt="GB STUDY" className="w-14 h-14 object-contain mb-3 drop-shadow-[0_0_12px_rgba(245,158,11,0.4)]" />
              <span className="font-semibold text-white">Search across all 46 batches, lectures, and notes in GB STUDY</span>
              <span className="text-[11px] text-stone-500 mt-1">Type course name, subject, or chapter to find lessons</span>
            </div>
          )}

          {query && matchedBatches.length === 0 && matchedLectures.length === 0 && (
            <div className="py-10 text-center text-stone-400 text-xs sm:text-sm">
              No matching courses or lectures found for "{query}". Try another keyword like "Physics", "Maths", "Class 10", "NDA", etc.
            </div>
          )}

          {/* Batches Results */}
          {matchedBatches.length > 0 && (
            <div>
              <div className="text-xs font-black uppercase tracking-wider text-purple-400 mb-3 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Batches ({matchedBatches.length})</span>
              </div>
              <div className="space-y-2">
                {matchedBatches.slice(0, 8).map(batch => (
                  <div
                    key={batch.id}
                    onClick={() => { onSelectBatch(batch); onClose(); }}
                    className="gb-card rounded-xl p-3 flex items-center justify-between gap-3 cursor-pointer hover:border-purple-500/50 group transition-all"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-12 h-12 rounded-lg bg-black/60 overflow-hidden shrink-0 border border-white/10">
                        <img 
                          src={batch.thumbnail} 
                          alt="" 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
                        />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                          {batch.title}
                        </h4>
                        <span className="text-[10px] text-purple-400 font-semibold">
                          {batch.classTag || 'Batch'}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-stone-500 group-hover:text-white shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Lectures & Notes Results */}
          {matchedLectures.length > 0 && (
            <div>
              <div className="text-xs font-black uppercase tracking-wider text-purple-400 mb-3 flex items-center gap-1.5">
                <Play className="w-3.5 h-3.5" />
                <span>Lectures & Notes ({matchedLectures.length})</span>
              </div>
              <div className="space-y-2">
                {matchedLectures.map(({ courseId, item }) => {
                  const isVideo = (item.material_type || '').toUpperCase() === 'VIDEO';
                  const pdfUrl = item.pdf_link || item.file_link || item.download_link;

                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        if (isVideo) {
                          onPlayVideo(item, courseId);
                          onClose();
                        } else if (pdfUrl) {
                          onOpenPdf(item.Title, pdfUrl);
                          onClose();
                        }
                      }}
                      className="gb-card rounded-xl p-3 flex items-center justify-between gap-3 cursor-pointer hover:border-purple-500/50 group transition-all"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-lg bg-purple-500/10 border border-purple-500/25 flex items-center justify-center shrink-0">
                          {isVideo ? (
                            <Play className="w-4 h-4 text-purple-400 fill-purple-400" />
                          ) : (
                            <FileText className="w-4 h-4 text-cyan-400" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs sm:text-sm font-semibold text-white group-hover:text-purple-300 transition-colors truncate">
                            {item.Title}
                          </h4>
                          <span className="text-[10px] text-stone-400">
                            {isVideo ? 'Lecture Video' : 'Study Notes / PDF'}
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-500 group-hover:text-white shrink-0" />
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
