import React from 'react';

interface GBStudyLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const GBStudyLogo: React.FC<GBStudyLogoProps> = ({
  className = '',
  size = 'md',
  showText = false,
}) => {
  const sizeMap = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <div className={`relative ${sizeMap[size]} shrink-0 group`}>
        {/* Glow effect */}
        <div className="absolute inset-0 bg-amber-500/25 rounded-2xl blur-md group-hover:bg-amber-400/40 transition-all" />
        <img
          src="/gb_logo.svg"
          alt="GB STUDY"
          className="relative w-full h-full object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] transform group-hover:scale-105 transition-transform duration-300"
        />
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-black tracking-wider text-white">
              GB <span className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 bg-clip-text text-transparent drop-shadow-[0_2px_8px_rgba(245,158,11,0.4)]">STUDY</span>
            </span>
            <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-amber-300 border border-amber-500/30">
              OFFICIAL
            </span>
          </div>
          <span className="text-[10px] text-stone-400 font-semibold tracking-wide">
            Free Batches • Notes • Lectures
          </span>
        </div>
      )}
    </div>
  );
};
