import React from 'react';
import { BookOpen, Bookmark, Search, Send, FileText } from 'lucide-react';
import { TELEGRAM_URL } from './TelegramModal';

interface MobileBottomNavProps {
  currentView: 'batches' | 'enrolled' | 'notes';
  onNavigate: (view: 'batches' | 'enrolled' | 'notes') => void;
  enrolledCount: number;
  onOpenSearch: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentView,
  onNavigate,
  enrolledCount,
  onOpenSearch,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-[#0a0510]/95 backdrop-blur-xl border-t border-purple-500/20 px-2 py-1.5 flex items-center justify-around shadow-[0_-5px_20px_rgba(0,0,0,0.5)]">
      {/* Batches Tab */}
      <button
        onClick={() => onNavigate('batches')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-colors ${
          currentView === 'batches' ? 'text-amber-300 font-bold' : 'text-stone-400 hover:text-stone-200'
        }`}
      >
        <img src="/gb_logo.svg" alt="" className={`w-5 h-5 object-contain ${currentView === 'batches' ? 'scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]' : 'opacity-70'}`} />
        <span className="text-[10px]">Batches</span>
      </button>

      {/* Enrolled Tab */}
      <button
        onClick={() => onNavigate('enrolled')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-colors relative ${
          currentView === 'enrolled' ? 'text-purple-300 font-bold' : 'text-stone-400 hover:text-stone-200'
        }`}
      >
        <Bookmark className="w-5 h-5" />
        <span className="text-[10px]">Enrolled</span>
        {enrolledCount > 0 && (
          <span className="absolute top-0 right-2 w-2 h-2 rounded-full bg-emerald-400" />
        )}
      </button>

      {/* Search Button */}
      <button
        onClick={onOpenSearch}
        className="flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-stone-400 hover:text-stone-200 transition-colors"
      >
        <Search className="w-5 h-5" />
        <span className="text-[10px]">Search</span>
      </button>

      {/* Notes Tab */}
      <button
        onClick={() => onNavigate('notes')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-colors ${
          currentView === 'notes' ? 'text-purple-300 font-bold' : 'text-stone-400 hover:text-stone-200'
        }`}
      >
        <FileText className="w-5 h-5" />
        <span className="text-[10px]">Notes</span>
      </button>

      {/* Telegram Link */}
      <a
        href={TELEGRAM_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-cyan-400 hover:text-cyan-300 transition-colors"
      >
        <Send className="w-5 h-5 fill-cyan-400/20" />
        <span className="text-[10px] font-bold">Telegram</span>
      </a>
    </div>
  );
};
