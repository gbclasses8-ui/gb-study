import React from 'react';
import { Batch } from '../types';
import { Bookmark, Sparkles, PlayCircle, BookOpen, Layers } from 'lucide-react';

interface BatchCardProps {
  batch: Batch;
  isEnrolled: boolean;
  onToggleEnroll: (id: string | number) => void;
  onOpenBatch: (batch: Batch) => void;
  index?: number;
}

export const BatchCard: React.FC<BatchCardProps> = ({
  batch,
  isEnrolled,
  onToggleEnroll,
  onOpenBatch,
}) => {
  return (
    <div className="gb-card rounded-2xl overflow-hidden flex flex-col group relative border border-purple-500/15 transition-all duration-300 hover:border-purple-500/50 hover:shadow-[0_15px_35px_-10px_rgba(168,85,247,0.3)]">
      {/* Thumbnail Banner */}
      <div 
        onClick={() => onOpenBatch(batch)}
        className="relative w-full aspect-video bg-[#0c0512] overflow-hidden cursor-pointer select-none"
      >
        <img
          src={batch.thumbnail}
          alt={batch.title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          onError={(e) => {
            // fallback if remote image has an issue
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
        
        {/* Dark overlay for contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0d0614] via-transparent to-black/20 opacity-80" />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-1.5 flex-wrap">
            {batch.classTag && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-purple-950/80 backdrop-blur-md text-purple-300 border border-purple-500/30">
                {batch.classTag}
              </span>
            )}
            {batch.isLive && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-rose-950/80 backdrop-blur-md text-rose-300 border border-rose-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
                Live
              </span>
            )}
          </div>

          <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-black/80 backdrop-blur-md text-amber-300 border border-amber-500/40 flex items-center gap-1 shadow-sm">
            <img src="/gb_logo.svg" alt="" className="w-3.5 h-3.5 object-contain" />
            GB STUDY
          </span>
        </div>

        {/* Quick Play Hover Indicator */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40 backdrop-blur-[2px]">
          <div className="w-12 h-12 rounded-full bg-purple-600/90 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
            <PlayCircle className="w-7 h-7 fill-white/20" />
          </div>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          <h3 
            onClick={() => onOpenBatch(batch)}
            className="text-sm sm:text-base font-bold text-white group-hover:text-purple-300 transition-colors line-clamp-2 cursor-pointer leading-snug"
            title={batch.title}
          >
            {batch.title}
          </h3>

          <div className="flex items-center gap-2 mt-2.5 text-xs text-stone-400">
            <Layers className="w-3.5 h-3.5 text-purple-400 shrink-0" />
            <span className="truncate">Subjects, Video Lectures & Notes</span>
          </div>
        </div>

        {/* Card Footer Actions */}
        <div className="flex items-center gap-2 pt-4 mt-3 border-t border-white/5">
          <button
            onClick={() => onOpenBatch(batch)}
            className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold py-2.5 px-3.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 active:scale-95"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Open Batch</span>
          </button>

          <button
            onClick={() => onToggleEnroll(batch.id)}
            className={`p-2.5 rounded-xl border transition-all active:scale-95 ${
              isEnrolled
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                : 'bg-white/5 text-stone-400 hover:text-white border-white/10 hover:bg-white/10'
            }`}
            title={isEnrolled ? 'Enrolled / Saved' : 'Save to My Batches'}
          >
            <Bookmark className={`w-4 h-4 ${isEnrolled ? 'fill-emerald-400' : ''}`} />
          </button>
        </div>
      </div>
    </div>
  );
};
