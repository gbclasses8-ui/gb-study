import React, { useState } from 'react';
import { Batch, FolderItem } from '../types';
import localFolderCache from '../data/batchFoldersCache.json';
import { FileText, Download, ExternalLink, Search, Filter, BookOpen, Sparkles } from 'lucide-react';

interface NotesSectionProps {
  batches: Batch[];
  onOpenPdf: (title: string, url: string) => void;
  onOpenBatch: (batch: Batch) => void;
}

interface NoteEntry {
  item: FolderItem;
  batch: Batch;
  subject?: string;
}

export const NotesSection: React.FC<NotesSectionProps> = ({
  batches,
  onOpenPdf,
  onOpenBatch,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('all');

  // Extract all PDF/notes from cached folders
  const allNotes: NoteEntry[] = React.useMemo(() => {
    const list: NoteEntry[] = [];
    const cacheMap = localFolderCache as Record<string, FolderItem[]>;

    for (const [key, items] of Object.entries(cacheMap)) {
      const [courseId] = key.split('_');
      const batch = batches.find(b => String(b.id) === String(courseId));
      if (!batch) continue;

      for (const item of items) {
        const type = (item.material_type || item.type || '').toUpperCase();
        if (type === 'PDF' || type === 'NOTES' || item.pdf_link || item.file_link) {
          list.push({
            item,
            batch,
            subject: batch.category || 'General'
          });
        }
      }
    }
    return list;
  }, [batches]);

  const classes = ['all', 'Class 12th', 'Class 11th', 'Class 10th', 'Class 9th', 'NDA & Defence'];

  const filteredNotes = allNotes.filter(({ item, batch }) => {
    const title = (item.Title || item.title || '').toLowerCase();
    const batchTitle = batch.title.toLowerCase();
    const q = searchQuery.toLowerCase();

    const matchesSearch = !q || title.includes(q) || batchTitle.includes(q);
    const matchesClass = selectedClass === 'all' || batch.classTag === selectedClass;

    return matchesSearch && matchesClass;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24">
      {/* Title Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold mb-3">
          <img src="/gb_logo.svg" alt="" className="w-3.5 h-3.5 object-contain" />
          GB STUDY Official Notes
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white">
          Notes, E-Books & Revision PDFs
        </h1>
        <p className="text-stone-400 text-xs sm:text-sm mt-1 max-w-2xl">
          Browse comprehensive topper notes, formula books, chapter summary sheets, and practice PDFs across all GB STUDY batches.
        </p>
      </div>

      {/* Controls Bar */}
      <div className="flex flex-col md:flex-row gap-4 mb-8 items-stretch md:items-center justify-between">
        {/* Class filters */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {classes.map(cls => (
            <button
              key={cls}
              onClick={() => setSelectedClass(cls)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                selectedClass === cls
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-white/5 text-stone-400 hover:text-white border border-white/10'
              }`}
            >
              {cls === 'all' ? 'All Classes' : cls}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search notes or chapters..."
            className="w-full bg-[#130a1c] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500"
          />
        </div>
      </div>

      {/* Notes Grid */}
      {filteredNotes.length === 0 ? (
        <div className="gb-card rounded-2xl p-12 text-center flex flex-col items-center justify-center max-w-md mx-auto">
          <FileText className="w-12 h-12 text-purple-400/40 mb-3" />
          <h3 className="text-base font-bold text-white mb-1">No notes match your filters</h3>
          <p className="text-xs text-stone-400 mb-4">
            Try adjusting your search query or view all classes to see available study PDFs.
          </p>
          <button
            onClick={() => { setSearchQuery(''); setSelectedClass('all'); }}
            className="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {filteredNotes.map(({ item, batch }, idx) => {
            const title = item.Title || item.title || 'Educational Document';
            const pdfUrl = item.pdf_link || item.file_link || item.download_link || '';
            const published = item.date_and_time || item.event_date;

            return (
              <div
                key={item.id + '_' + idx}
                className="gb-card rounded-2xl p-4 sm:p-5 flex flex-col justify-between border border-purple-500/15 hover:border-purple-500/40 group transition-all"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {batch.classTag || 'Study Material'}
                    </span>
                    <span className="text-[10px] text-stone-500">
                      PDF Document
                    </span>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <FileText className="w-5 h-5 text-purple-400" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors line-clamp-2 leading-snug">
                        {title}
                      </h3>
                      <p className="text-[11px] text-stone-400 mt-1 truncate">
                        From: {batch.title}
                      </p>
                      {published && (
                        <p className="text-[10px] text-stone-500 mt-0.5">
                          Date: {published}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="flex items-center gap-2 pt-4 mt-4 border-t border-white/5">
                  <button
                    onClick={() => onOpenPdf(title, pdfUrl)}
                    className="flex-1 bg-white hover:bg-stone-200 text-black text-xs font-black uppercase tracking-wider py-2 px-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 active:scale-95"
                  >
                    <span>Read PDF</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onOpenBatch(batch)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white border border-white/10 transition-colors"
                    title="View Batch Full Content"
                  >
                    <BookOpen className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
