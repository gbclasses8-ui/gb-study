import React from 'react';
import { Send, X, ExternalLink, Sparkles, CheckCircle2 } from 'lucide-react';
import { GBStudyLogo } from './GBStudyLogo';

interface TelegramModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TELEGRAM_URL = 'https://t.me/GBFreestudy';

export const TelegramModal: React.FC<TelegramModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleJoin = () => {
    window.open(TELEGRAM_URL, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md transition-opacity duration-300">
      <div 
        className="gb-modal-glass w-full max-w-md rounded-3xl p-6 sm:p-8 relative overflow-hidden transform transition-all duration-300 border border-amber-500/30 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_40px_rgba(245,158,11,0.25)]"
        role="dialog"
        aria-modal="true"
      >
        {/* Decorative background glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/25 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-[#0088cc]/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-stone-400 hover:text-white transition-colors p-2 rounded-xl hover:bg-white/10"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with 3D GB STUDY Emblem */}
        <div className="text-center mb-6">
          <div className="flex justify-center mb-4">
            <GBStudyLogo size="xl" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Official Student Community
          </div>

          <h2 className="text-2xl font-black text-white tracking-tight sm:text-3xl">
            Join <span className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 bg-clip-text text-transparent">GB STUDY</span> Telegram Channel
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 mt-2.5 leading-relaxed">
            Get instant free batch updates, chapter-wise PDF notes, daily class notifications, formula sheets & live discussion with students!
          </p>
        </div>

        {/* Channel Benefits */}
        <div className="space-y-2.5 mb-7 bg-white/5 border border-white/10 rounded-2xl p-4">
          <div className="flex items-center gap-2.5 text-xs sm:text-sm text-stone-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Direct lecture links & test series updates</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs sm:text-sm text-stone-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Handwritten topper notes & mind maps</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs sm:text-sm text-stone-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Channel: <span className="text-cyan-400 font-mono font-bold">@GBFreestudy</span></span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleJoin}
            className="flex-1 bg-gradient-to-r from-[#0088cc] to-[#229ED9] hover:from-[#0095e0] hover:to-[#2cb0f3] text-white font-bold py-3.5 px-5 rounded-xl shadow-[0_0_25px_rgba(0,136,204,0.4)] transition-all flex items-center justify-center gap-2 active:scale-95"
          >
            <Send className="w-4 h-4 fill-white" />
            <span>Join Telegram</span>
            <ExternalLink className="w-4 h-4 opacity-75" />
          </button>
          <button
            onClick={onClose}
            className="py-3.5 px-5 rounded-xl bg-white/10 hover:bg-white/15 text-stone-300 hover:text-white font-semibold text-sm transition-colors border border-white/10 active:scale-95"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
