import React, { useState, useEffect } from 'react';
import { Batch, FolderItem, BreadcrumbCrumb } from '../types';
import { fetchFolderContents } from '../services/api';
import { 
  ArrowLeft, 
  Folder, 
  Play, 
  FileText, 
  Calendar, 
  Clock, 
  ChevronRight, 
  ExternalLink, 
  Share2, 
  Bookmark, 
  RefreshCw, 
  Sparkles,
  AlertCircle,
  HelpCircle,
  Download
} from 'lucide-react';

interface BatchExplorerProps {
  batch: Batch;
  onBack: () => void;
  isEnrolled: boolean;
  onToggleEnroll: (id: string | number) => void;
  onPlayVideo: (item: FolderItem, allVideosInFolder: FolderItem[]) => void;
  onOpenPdf: (title: string, url: string) => void;
  onShowToast: (msg: string) => void;
}

export const BatchExplorer: React.FC<BatchExplorerProps> = ({
  batch,
  onBack,
  isEnrolled,
  onToggleEnroll,
  onPlayVideo,
  onOpenPdf,
  onShowToast,
}) => {
  const [navigationStack, setNavigationStack] = useState<BreadcrumbCrumb[]>([
    { id: '-1', title: batch.title }
  ]);
  const [items, setItems] = useState<FolderItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'folders' | 'videos' | 'notes'>('all');

  const currentFolder = navigationStack[navigationStack.length - 1];

  useEffect(() => {
    loadFolder(currentFolder.id);
  }, [currentFolder.id, batch.id]);

  const loadFolder = async (folderId: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchFolderContents(String(batch.id), folderId);
      
      // Auto-drilldown: If the root only has a single "Home" folder, automatically open it
      if (folderId === '-1' && data.length === 1 && data[0].material_type === 'FOLDER' && data[0].Title.toLowerCase().includes('home')) {
        setNavigationStack(prev => [...prev, { id: data[0].id, title: 'Subjects' }]);
        return;
      }
      
      setItems(data);
    } catch (err: any) {
      console.error('Failed to load folder:', err);
      setError('Unable to fetch contents from server. Please retry or check your internet.');
    } finally {
      setLoading(false);
    }
  };

  const handleFolderClick = (item: FolderItem) => {
    setNavigationStack(prev => [...prev, { id: item.id, title: item.Title }]);
  };

  const handleBreadcrumbClick = (index: number) => {
    setNavigationStack(prev => prev.slice(0, index + 1));
  };

  const handleBackStep = () => {
    if (navigationStack.length > 1) {
      setNavigationStack(prev => prev.slice(0, prev.length - 1));
    } else {
      onBack();
    }
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      onShowToast('Batch link copied to clipboard!');
    }
  };

  // Filter items
  const filteredItems = items.filter(item => {
    const type = (item.material_type || '').toUpperCase();
    if (activeFilter === 'folders') return type === 'FOLDER';
    if (activeFilter === 'videos') return type === 'VIDEO';
    if (activeFilter === 'notes') return type === 'PDF' || type === 'NOTES';
    return true;
  });

  const allVideosInFolder = items.filter(it => (it.material_type || '').toUpperCase() === 'VIDEO');

  // Stats calculation
  const folderCount = items.filter(i => (i.material_type || '').toUpperCase() === 'FOLDER').length;
  const videoCount = items.filter(i => (i.material_type || '').toUpperCase() === 'VIDEO').length;
  const pdfCount = items.filter(i => (i.material_type || '').toUpperCase() === 'PDF' || (i.material_type || '').toUpperCase() === 'NOTES').length;

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24">
      {/* Top Navigation Controls */}
      <div className="flex items-center justify-between mb-6 gap-3">
        <button
          onClick={handleBackStep}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white border border-white/10 text-xs sm:text-sm font-semibold transition-all active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{navigationStack.length > 1 ? 'Back' : 'All Batches'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white border border-white/10 text-xs font-medium transition-all"
            title="Share Batch"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Share</span>
          </button>

          <button
            onClick={() => onToggleEnroll(batch.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
              isEnrolled
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                : 'bg-purple-600/20 text-purple-300 border-purple-500/30 hover:bg-purple-600/30'
            }`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isEnrolled ? 'fill-emerald-400' : ''}`} />
            <span>{isEnrolled ? 'Enrolled' : 'Enroll Batch'}</span>
          </button>
        </div>
      </div>

      {/* Course Hero Banner */}
      <div className="gb-card rounded-3xl p-5 sm:p-7 mb-8 border border-purple-500/25 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row gap-5 sm:gap-7 items-start md:items-center">
          <div className="w-full md:w-56 lg:w-64 aspect-video rounded-2xl overflow-hidden bg-black/50 border border-purple-500/30 shrink-0 shadow-lg">
            <img
              src={batch.thumbnail}
              alt={batch.title}
              className="w-full h-full object-cover"
              onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                <img src="/gb_logo.svg" alt="" className="w-3.5 h-3.5 object-contain" />
                GB STUDY Official
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {batch.classTag || 'Educational Batch'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                100% Free
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-white leading-tight">
              {batch.title}
            </h1>

            <p className="text-xs sm:text-sm text-stone-400 mt-2 leading-relaxed">
              Full curriculum course with recorded video lectures, live classes, DPP sheets, chapter PDFs, and revision notes.
            </p>

            <div className="flex items-center gap-4 mt-4 text-xs font-semibold text-stone-300 flex-wrap">
              <div className="flex items-center gap-1.5">
                <Folder className="w-4 h-4 text-purple-400" />
                <span>{folderCount > 0 ? `${folderCount} Sections` : 'Structured Subjects'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Play className="w-4 h-4 text-purple-400" />
                <span>{videoCount > 0 ? `${videoCount} Lectures` : 'Video Lessons'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-purple-400" />
                <span>{pdfCount > 0 ? `${pdfCount} Notes / PDFs` : 'PDF Notes'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb Navigation Trail */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-2 px-3 bg-[#130a1c]/70 backdrop-blur-md rounded-2xl border border-white/10 mb-6 text-xs sm:text-sm">
        {navigationStack.map((crumb, idx) => {
          const isLast = idx === navigationStack.length - 1;
          return (
            <React.Fragment key={crumb.id + '_' + idx}>
              <button
                onClick={() => handleBreadcrumbClick(idx)}
                className={`truncate max-w-[180px] sm:max-w-[260px] font-semibold transition-colors ${
                  isLast
                    ? 'text-purple-300 font-bold pointer-events-none'
                    : 'text-stone-400 hover:text-white'
                }`}
              >
                {crumb.title}
              </button>
              {!isLast && <ChevronRight className="w-3.5 h-3.5 text-stone-600 shrink-0" />}
            </React.Fragment>
          );
        })}
      </div>

      {/* Filter Tabs within folder */}
      {items.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mb-6">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeFilter === 'all'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-white/5 text-stone-400 hover:text-white border border-white/10'
            }`}
          >
            All Items ({items.length})
          </button>
          {folderCount > 0 && (
            <button
              onClick={() => setActiveFilter('folders')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                activeFilter === 'folders'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-white/5 text-stone-400 hover:text-white border border-white/10'
              }`}
            >
              Folders ({folderCount})
            </button>
          )}
          {videoCount > 0 && (
            <button
              onClick={() => setActiveFilter('videos')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                activeFilter === 'videos'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-white/5 text-stone-400 hover:text-white border border-white/10'
              }`}
            >
              Lectures ({videoCount})
            </button>
          )}
          {pdfCount > 0 && (
            <button
              onClick={() => setActiveFilter('notes')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                activeFilter === 'notes'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-white/5 text-stone-400 hover:text-white border border-white/10'
              }`}
            >
              Notes / PDFs ({pdfCount})
            </button>
          )}
        </div>
      )}

      {/* Loading Skeletons */}
      {loading && (
        <div className="space-y-3.5">
          {[1, 2, 3, 4, 5].map((n) => (
            <div key={n} className="gb-card rounded-2xl p-4 flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl gb-shimmer shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="w-1/2 h-4 rounded-md gb-shimmer" />
                <div className="w-1/4 h-3 rounded-md gb-shimmer" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Error state */}
      {!loading && error && (
        <div className="gb-card rounded-2xl p-8 text-center flex flex-col items-center justify-center max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center mb-4">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-white mb-1">Failed to load content</h3>
          <p className="text-xs text-stone-400 mb-5">{error}</p>
          <button
            onClick={() => loadFolder(currentFolder.id)}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Try Again</span>
          </button>
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && filteredItems.length === 0 && (
        <div className="gb-card rounded-2xl p-12 text-center flex flex-col items-center justify-center max-w-md mx-auto">
          <div className="w-16 h-16 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-4">
            <Folder className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white mb-1">No items found</h3>
          <p className="text-xs text-stone-400 mb-4">
            This section doesn't have any matching items yet. Try switching filters or going back.
          </p>
          <button
            onClick={handleBackStep}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-stone-200 text-xs font-bold transition-all"
          >
            Go Back
          </button>
        </div>
      )}

      {/* Content Grid / List */}
      {!loading && !error && filteredItems.length > 0 && (
        <div className="space-y-3 sm:space-y-4">
          {filteredItems.map((item) => {
            const type = (item.material_type || item.type || '').toUpperCase();
            const title = item.Title || item.title || 'Untitled';
            const pdfUrl = item.pdf_link || item.file_link || item.download_link;

            // FOLDER ITEM
            if (type === 'FOLDER') {
              let counts: string[] = [];
              if (Number(item.videos_count) > 0) counts.push(`${item.videos_count} Videos`);
              if (Number(item.files_count) > 0) counts.push(`${item.files_count} PDFs`);
              if (Number(item.tests_count) > 0) counts.push(`${item.tests_count} Tests`);
              const countText = counts.length > 0 ? counts.join(' • ') : 'View Folder';

              return (
                <div
                  key={item.id}
                  onClick={() => handleFolderClick(item)}
                  className="gb-card rounded-2xl p-3.5 sm:p-4.5 cursor-pointer flex items-center justify-between gap-4 group border border-purple-500/15 hover:border-purple-500/40"
                >
                  <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-purple-500/10 border border-purple-500/25 flex items-center justify-center shrink-0 group-hover:scale-105 group-hover:bg-purple-500/20 transition-all">
                      {item.thumbnail ? (
                        <img 
                          src={item.thumbnail} 
                          alt="" 
                          className="w-full h-full object-contain p-1 rounded-xl"
                          onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                        />
                      ) : (
                        <Folder className="w-6 h-6 text-purple-400 group-hover:text-purple-300" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                        {title}
                      </h3>
                      <p className="text-xs text-purple-400/80 font-medium mt-0.5">
                        {countText}
                      </p>
                    </div>
                  </div>

                  <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-all text-stone-400">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              );
            }

            // VIDEO ITEM
            if (type === 'VIDEO') {
              const duration = item.duration || (item.duration_in_secs ? `${Math.floor(Number(item.duration_in_secs) / 60)} mins` : '');
              const published = item.date_and_time || item.event_date || '';

              return (
                <div
                  key={item.id}
                  className="gb-card rounded-2xl p-3.5 sm:p-4.5 flex flex-col sm:flex-row gap-4 border border-purple-500/15 hover:border-purple-500/40 group"
                >
                  {/* Thumbnail */}
                  <div 
                    onClick={() => onPlayVideo(item, allVideosInFolder)}
                    className="w-full sm:w-48 lg:w-56 aspect-video bg-black/60 rounded-xl relative overflow-hidden shrink-0 cursor-pointer border border-white/10 group-hover:border-purple-500/40"
                  >
                    {item.thumbnail ? (
                      <img
                        src={item.thumbnail}
                        alt=""
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-[#0d0714]">
                        <Play className="w-8 h-8 text-purple-400 opacity-60" />
                      </div>
                    )}

                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-80 group-hover:opacity-100 transition-opacity">
                      <div className="w-10 h-10 rounded-full bg-purple-600/90 text-white flex items-center justify-center shadow-md">
                        <Play className="w-5 h-5 fill-white ml-0.5" />
                      </div>
                    </div>

                    {duration && (
                      <div className="absolute bottom-2 right-2 bg-black/80 backdrop-blur-sm px-2 py-0.5 rounded text-[10px] font-bold text-white border border-white/10 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-purple-300" />
                        <span>{duration}</span>
                      </div>
                    )}
                  </div>

                  {/* Info & Actions */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded text-[9px] font-extrabold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          Lecture
                        </span>
                        {published && (
                          <span className="text-[11px] text-stone-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3" /> {published}
                          </span>
                        )}
                      </div>

                      <h3 
                        onClick={() => onPlayVideo(item, allVideosInFolder)}
                        className="text-sm sm:text-base font-bold text-white hover:text-purple-300 transition-colors line-clamp-2 cursor-pointer leading-snug"
                      >
                        {title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-2.5 mt-3 sm:mt-2 flex-wrap">
                      <button
                        onClick={() => onPlayVideo(item, allVideosInFolder)}
                        className="bg-white hover:bg-stone-200 text-black px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                      >
                        <Play className="w-3.5 h-3.5 fill-black" />
                        <span>Watch Lecture</span>
                      </button>

                      {pdfUrl && (
                        <button
                          onClick={() => onOpenPdf(title + ' - Notes', pdfUrl)}
                          className="bg-purple-600/20 text-purple-300 hover:bg-purple-600/30 border border-purple-500/30 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Lecture Notes</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            }

            // PDF / NOTES ITEM
            if (type === 'PDF' || type === 'NOTES') {
              const published = item.date_and_time || item.event_date || '';

              return (
                <div
                  key={item.id}
                  className="gb-card rounded-2xl p-3.5 sm:p-4.5 flex items-center justify-between gap-4 border border-purple-500/15 hover:border-purple-500/40 group"
                >
                  <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                    <div className="w-12 h-12 rounded-xl bg-purple-500/15 border border-purple-500/25 flex items-center justify-center shrink-0 group-hover:scale-105 group-hover:bg-purple-500/25 transition-all">
                      <FileText className="w-6 h-6 text-purple-400 group-hover:text-purple-300" />
                    </div>

                    <div className="min-w-0">
                      <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                        {title}
                      </h3>
                      {published && (
                        <p className="text-xs text-stone-400 mt-0.5 flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {published}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onOpenPdf(title, pdfUrl || '')}
                      className="bg-white hover:bg-stone-200 text-black px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                    >
                      <span>Read PDF</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            }

            // Other general items
            return (
              <div
                key={item.id}
                className="gb-card rounded-2xl p-4 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-5 h-5 text-stone-400" />
                  <span className="text-sm font-semibold text-white">{title}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
