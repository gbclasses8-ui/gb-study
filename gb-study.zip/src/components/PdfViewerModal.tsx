import React, { useState } from 'react';
import { GBStudyLogo } from './GBStudyLogo';
import { X, ExternalLink, Download, FileText, Share2, Layers, RefreshCw } from 'lucide-react';

interface PdfViewerModalProps {
  title: string;
  pdfUrl: string;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  title,
  pdfUrl,
  onClose,
  onShowToast,
}) => {
  if (!pdfUrl) return null;

  const [useGoogleDocs, setUseGoogleDocs] = useState<boolean>(true);

  const handleOpenExternal = () => {
    window.open(pdfUrl, '_blank', 'noopener,noreferrer');
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(pdfUrl);
      onShowToast('PDF link copied to clipboard!');
    }
  };

  const docsViewerUrl = `https://docs.google.com/viewer?url=${encodeURIComponent(pdfUrl)}&embedded=true`;
  const proxiedPdfUrl = `/pdf?url=${encodeURIComponent(pdfUrl)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/92 backdrop-blur-md">
      <div className="gb-modal-glass w-full max-w-5xl h-[94vh] rounded-3xl overflow-hidden flex flex-col relative border border-amber-500/30 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.9),0_0_40px_rgba(245,158,11,0.2)]">
        {/* Header bar with GB STUDY Logo */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-black/60 border-b border-amber-500/20 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <GBStudyLogo size="sm" />
            <div className="min-w-0">
              <span className="px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                GB STUDY Notes Reader
              </span>
              <h2 className="text-xs sm:text-sm font-bold text-white truncate max-w-sm sm:max-w-md" title={title}>
                {title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Toggle Viewer Engine */}
            <button
              onClick={() => setUseGoogleDocs(prev => !prev)}
              className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1 transition-all"
              title="Toggle PDF viewer engine"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{useGoogleDocs ? 'Native PDF View' : 'Google Docs View'}</span>
            </button>

            <button
              onClick={handleShare}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white transition-all text-xs"
              title="Share PDF link"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              onClick={handleOpenExternal}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-black text-xs font-black flex items-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <span>Open in New Tab</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close PDF Viewer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Embedded PDF container */}
        <div className="flex-1 w-full bg-[#0d0714] relative flex flex-col">
          {useGoogleDocs ? (
            <iframe
              src={docsViewerUrl}
              title={title}
              className="w-full flex-1 border-0"
            />
          ) : (
            <object
              data={proxiedPdfUrl}
              type="application/pdf"
              className="w-full flex-1 border-0"
            >
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0d0714]">
                <FileText className="w-12 h-12 text-amber-400 mb-3" />
                <h3 className="text-base font-bold text-white mb-2">Ready to read your document</h3>
                <p className="text-xs text-stone-300 mb-5 max-w-sm">
                  Click below to view this PDF note directly in your browser or switch back to Google Docs reader.
                </p>
                <div className="flex items-center gap-3">
                  <a
                    href={pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-5 py-2.5 rounded-xl bg-amber-500 text-black font-bold text-xs shadow-md flex items-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Open PDF Directly</span>
                  </a>
                  <button
                    onClick={() => setUseGoogleDocs(true)}
                    className="px-4 py-2.5 rounded-xl bg-white/10 text-white text-xs font-bold"
                  >
                    Use Google Viewer
                  </button>
                </div>
              </div>
            </object>
          )}

          {/* Bottom Bar */}
          <div className="px-4 py-2.5 bg-black/70 border-t border-amber-500/20 flex items-center justify-between text-xs text-stone-400">
            <div className="flex items-center gap-2">
              <GBStudyLogo size="sm" />
              <span>Official GB STUDY Notes Document</span>
            </div>
            <div className="flex items-center gap-4">
              <a
                href={pdfUrl}
                target="_blank"
                rel="noopener noreferrer"
                download
                className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Direct Download PDF</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
