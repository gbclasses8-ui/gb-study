import React from 'react';
import { Send, ExternalLink } from 'lucide-react';
import { TELEGRAM_URL } from './TelegramModal';
import { GBStudyLogo } from './GBStudyLogo';

interface FooterProps {
  onOpenTelegram: () => void;
  onFilterClass: (tag: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenTelegram, onFilterClass }) => {
  return (
    <footer className="w-full bg-[#07030a] border-t border-amber-500/15 relative z-10 pt-12 pb-24 md:pb-12 text-stone-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Telegram Call to action card */}
        <div className="gb-card rounded-3xl p-6 sm:p-8 mb-12 border border-amber-500/25 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 shadow-[0_10px_40px_-10px_rgba(245,158,11,0.15)]">
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center gap-4 text-center md:text-left">
            <GBStudyLogo size="lg" />
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                Join <span className="text-amber-400">GB STUDY</span> on Telegram
              </h3>
              <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-lg">
                Never miss an update! Get direct access to all class batches, handwritten notes, live lecture alerts, and test papers.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href={TELEGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#0088cc] to-[#229ED9] hover:from-[#0095e0] hover:to-[#2cb0f3] text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-[0_0_20px_rgba(0,136,204,0.35)] transition-all active:scale-95"
            >
              <Send className="w-4 h-4 fill-white" />
              <span>Join Telegram</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-75" />
            </a>

            <button
              onClick={onOpenTelegram}
              className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-stone-200 text-xs sm:text-sm font-semibold border border-white/10 transition-all"
            >
              Community
            </button>
          </div>
        </div>

        {/* Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10 text-xs">
          {/* Col 1 */}
          <div className="space-y-3">
            <GBStudyLogo size="md" showText={true} />
            <p className="text-stone-400 leading-relaxed pt-2">
              Your premier digital learning portal for CBSE Class 9th to 12th, NEET, JEE, NDA, and CA Foundation exam preparation.
            </p>
          </div>

          {/* Col 2 */}
          <div className="space-y-2.5">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider text-amber-400">Top Classes</h4>
            <div className="flex flex-col space-y-1.5">
              <button onClick={() => onFilterClass('Class 12th')} className="text-left hover:text-amber-300 transition-colors">Class 12th Science & Commerce</button>
              <button onClick={() => onFilterClass('Class 11th')} className="text-left hover:text-amber-300 transition-colors">Class 11th Science & Commerce</button>
              <button onClick={() => onFilterClass('Class 10th')} className="text-left hover:text-amber-300 transition-colors">Class 10th Board Foundation</button>
              <button onClick={() => onFilterClass('Class 9th')} className="text-left hover:text-amber-300 transition-colors">Class 9th Newton Batches</button>
            </div>
          </div>

          {/* Col 3 */}
          <div className="space-y-2.5">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider text-amber-400">Competitive Exams</h4>
            <div className="flex flex-col space-y-1.5">
              <button onClick={() => onFilterClass('NDA & Defence')} className="text-left hover:text-amber-300 transition-colors">Tejas & Udaan NDA Batches</button>
              <button onClick={() => onFilterClass('CA Foundation')} className="text-left hover:text-amber-300 transition-colors">CA Foundation Buniyaad</button>
              <button onClick={() => onFilterClass('JEE / NEET')} className="text-left hover:text-amber-300 transition-colors">JEE / NEET Crash Courses</button>
              <button onClick={() => onFilterClass('CUET')} className="text-left hover:text-amber-300 transition-colors">CUET 2026/2027 Batches</button>
            </div>
          </div>

          {/* Col 4 */}
          <div className="space-y-2.5">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider text-amber-400">Official Channel</h4>
            <p className="text-stone-400 leading-relaxed">
              Join thousands of students on our official Telegram channel for daily schedules and materials.
            </p>
            <a
              href={TELEGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-bold"
            >
              <span>@GBFreestudy</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500">
          <div>
            © {new Date().getFullYear()} GB STUDY. All rights reserved.
          </div>
          <div className="flex items-center gap-2 text-stone-400">
            <span>Built for students with dedication</span>
            <span>•</span>
            <span className="text-amber-400 font-bold">GB STUDY</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
