import React from 'react';
import { BookOpen, Bookmark, Search, Send, Sparkles } from 'lucide-react';
import { GBStudyLogo } from './GBStudyLogo';

interface HeaderProps {
  currentView: 'batches' | 'enrolled' | 'notes';
  onNavigate: (view: 'batches' | 'enrolled' | 'notes') => void;
  enrolledCount: number;
  onOpenSearch: () => void;
  onOpenTelegram: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  enrolledCount,
  onOpenSearch,
  onOpenTelegram,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full gb-nav-glass transition-colors duration-200 border-b border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-[74px] flex items-center justify-between gap-4">
        {/* Brand Logo with the user's 3D emblem */}
        <div 
          onClick={() => onNavigate('batches')}
          className="cursor-pointer group select-none flex items-center"
        >
          <GBStudyLogo size="md" showText={true} />
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1.5 lg:gap-2">
          <button
            onClick={() => onNavigate('batches')}
            className={`px-4 py-2 rounded-xl text-xs lg:text-sm font-bold transition-all flex items-center gap-2 ${
              currentView === 'batches'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                : 'text-stone-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>All Batches</span>
          </button>

          <button
            onClick={() => onNavigate('enrolled')}
            className={`px-4 py-2 rounded-xl text-xs lg:text-sm font-bold transition-all flex items-center gap-2 ${
              currentView === 'enrolled'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                : 'text-stone-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>My Enrolled</span>
            {enrolledCount > 0 && (
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-black px-1.5 py-0.2 rounded-md">
                {enrolledCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onNavigate('notes')}
            className={`px-4 py-2 rounded-xl text-xs lg:text-sm font-bold transition-all flex items-center gap-2 ${
              currentView === 'notes'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                : 'text-stone-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Notes & PDFs</span>
          </button>
        </nav>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-stone-300 hover:text-white text-xs font-medium transition-all"
            title="Search batches & lectures (Ctrl+K)"
          >
            <Search className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Search...</span>
            <kbd className="hidden lg:inline-block px-1.5 py-0.5 text-[10px] bg-black/40 rounded border border-white/10 text-stone-400">
              ⌘K
            </kbd>
          </button>

          {/* Telegram Action Button */}
          <button
            onClick={onOpenTelegram}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#0088cc] to-[#229ED9] hover:from-[#0095e0] hover:to-[#2cb0f3] text-white text-xs font-bold transition-all shadow-[0_0_15px_rgba(0,136,204,0.35)] active:scale-95"
          >
            <Send className="w-3.5 h-3.5 fill-white" />
            <span className="hidden sm:inline">Join Telegram</span>
            <span className="sm:hidden">Telegram</span>
          </button>
        </div>
      </div>
    </header>
  );
};
