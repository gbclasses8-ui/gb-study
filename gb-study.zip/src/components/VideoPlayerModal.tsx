import React, { useState, useEffect, useRef } from 'react';
import { FolderItem, VideoDetails, VideoQuality } from '../types';
import { fetchVideoDetails } from '../services/api';
import { GBStudyLogo } from './GBStudyLogo';
import { TELEGRAM_URL } from './TelegramModal';
import Hls from 'hls.js';
import { 
  X, 
  Play, 
  Pause, 
  RotateCcw, 
  RotateCw, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Settings, 
  ChevronRight, 
  ChevronLeft, 
  FileText, 
  Loader2, 
  Send,
  Calendar,
  ExternalLink,
  Sparkles,
  Layers,
  RefreshCw
} from 'lucide-react';

interface VideoPlayerModalProps {
  item: FolderItem;
  courseId: string;
  allVideos: FolderItem[];
  onClose: () => void;
  onOpenPdf: (title: string, url: string) => void;
  onSelectVideo: (item: FolderItem) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  item,
  courseId,
  allVideos,
  onClose,
  onOpenPdf,
  onSelectVideo,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [videoData, setVideoData] = useState<VideoDetails | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [selectedQuality, setSelectedQuality] = useState<string>('Auto');
  const [qualities, setQualities] = useState<VideoQuality[]>([]);
  const [currentStreamUrl, setCurrentStreamUrl] = useState<string>('');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  
  // Player mode: 'hls' (native HLS.js), 'embed' (official Akamai web player), 'youtube' (YouTube embed), 'upcoming'
  const [playerMode, setPlayerMode] = useState<'hls' | 'embed' | 'youtube' | 'upcoming'>('hls');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Prev / next calculation
  const currentIndex = allVideos.findIndex(v => v.id === item.id);
  const prevVideo = currentIndex > 0 ? allVideos[currentIndex - 1] : null;
  const nextVideo = currentIndex < allVideos.length - 1 ? allVideos[currentIndex + 1] : null;

  useEffect(() => {
    setupLectureStream();
    return () => {
      destroyHls();
    };
  }, [item.id, courseId]);

  const destroyHls = () => {
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
  };

  const setupLectureStream = async () => {
    setLoading(true);
    destroyHls();

    // 1. Try to fetch fresh video details from API
    let resolvedUrl = item.file_link || '';
    let fetchedQualities: VideoQuality[] = [];

    // Check livestream_links from item
    if (!resolvedUrl && Array.isArray(item.livestream_links) && item.livestream_links.length > 0) {
      const firstLive = item.livestream_links[0];
      if (typeof firstLive === 'object' && firstLive.path) {
        resolvedUrl = firstLive.path;
      }
    }

    try {
      const apiData = await fetchVideoDetails(courseId, item.id);
      if (apiData && (apiData.decoded_video_link || apiData.player_url || (apiData.qualities && apiData.qualities.length > 0))) {
        setVideoData(apiData);
        if (apiData.qualities && apiData.qualities.length > 0) {
          fetchedQualities = apiData.qualities;
          setQualities(fetchedQualities);
          resolvedUrl = apiData.qualities[0].url || apiData.decoded_video_link || resolvedUrl;
        } else if (apiData.decoded_video_link) {
          resolvedUrl = apiData.decoded_video_link;
        }
      }
    } catch {
      // Graceful fallback: continue with item.file_link
    }

    // Check YouTube ID (11 chars or youtube url)
    const isYouTube = resolvedUrl && (!resolvedUrl.includes('http') && resolvedUrl.length === 11) || resolvedUrl.includes('youtube.com') || resolvedUrl.includes('youtu.be');

    if (isYouTube) {
      const ytId = resolvedUrl.length === 11 ? resolvedUrl : extractYouTubeId(resolvedUrl);
      setCurrentStreamUrl(`https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0&modestbranding=1`);
      setPlayerMode('youtube');
      setLoading(false);
      return;
    }

    // Check if MPD (DASH) - DASH often requires Widevine or the official player
    if (resolvedUrl && resolvedUrl.toLowerCase().includes('.mpd')) {
      const akamaiPlayerUrl = `https://appx-play.akamai.net.in/video-player?url=${encodeURIComponent(resolvedUrl)}`;
      setCurrentStreamUrl(akamaiPlayerUrl);
      setPlayerMode('embed');
      setLoading(false);
      return;
    }

    // If stream URL is available (HLS .m3u8 or MP4)
    if (resolvedUrl) {
      setCurrentStreamUrl(resolvedUrl);
      setPlayerMode('hls');
      initHls(resolvedUrl);
    } else {
      // Upcoming or scheduled lecture
      setPlayerMode('upcoming');
      setLoading(false);
    }
  };

  const extractYouTubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : url;
  };

  const initHls = (url: string) => {
    const video = videoRef.current;
    if (!video) {
      setLoading(false);
      return;
    }

    destroyHls();

    // Prefer proxied stream if it's m3u8
    const proxiedUrl = url.includes('.m3u8') ? `/video?url=${encodeURIComponent(url)}` : url;

    if (url.includes('.m3u8') && Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 60,
      });
      hlsRef.current = hls;

      hls.loadSource(proxiedUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setLoading(false);
        video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      });

      hls.on(Hls.Events.ERROR, (_event, errorData) => {
        if (errorData.fatal) {
          switch (errorData.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              // Try direct URL without proxy
              hls.loadSource(url);
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              destroyHls();
              // Seamlessly fallback to Akamai official player so user NEVER sees an error!
              const fallbackPlayer = `https://appx-play.akamai.net.in/video-player?url=${encodeURIComponent(url)}`;
              setCurrentStreamUrl(fallbackPlayer);
              setPlayerMode('embed');
              setLoading(false);
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari / iOS native HLS
      video.src = proxiedUrl;
      video.addEventListener('loadedmetadata', () => {
        setLoading(false);
        video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      });
    } else {
      // standard video
      video.src = url;
      video.addEventListener('loadedmetadata', () => {
        setLoading(false);
        video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      });
    }
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (video) {
      setCurrentTime(video.currentTime);
      setDuration(video.duration || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (video) {
      const time = Number(e.target.value);
      video.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleSkip = (seconds: number) => {
    const video = videoRef.current;
    if (video) {
      video.currentTime = Math.min(Math.max(video.currentTime + seconds, 0), duration || 99999);
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setShowSettings(false);
  };

  const handleQualityChange = (q: VideoQuality) => {
    setSelectedQuality(q.quality);
    const curr = videoRef.current?.currentTime || 0;
    initHls(q.url);
    if (videoRef.current) {
      videoRef.current.currentTime = curr;
    }
    setShowSettings(false);
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (video) {
      video.muted = !video.muted;
      setIsMuted(video.muted);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '00:00';
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    if (h > 0) {
      return `${h}:${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    }
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const pdfUrl = item.pdf_link || item.file_link || item.download_link;
  const lectureTitle = item.Title || item.title || 'GB STUDY Lecture';
  const durationLabel = item.duration || (item.duration_in_secs ? `${Math.floor(Number(item.duration_in_secs) / 60)} mins` : '');
  const publishedDate = videoData?.date || item.date_and_time || item.event_date;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/92 backdrop-blur-md">
      <div 
        ref={containerRef}
        className="gb-modal-glass w-full max-w-5xl rounded-3xl overflow-hidden flex flex-col max-h-[96vh] relative border border-amber-500/30 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.9),0_0_40px_rgba(245,158,11,0.2)]"
      >
        {/* Top Header Bar with GB STUDY Icon */}
        <div className="px-4 py-3 sm:px-6 sm:py-3.5 bg-black/60 border-b border-amber-500/20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <GBStudyLogo size="sm" />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  GB STUDY Player
                </span>
                {durationLabel && (
                  <span className="text-[11px] text-stone-400 hidden sm:inline">
                    {durationLabel}
                  </span>
                )}
              </div>
              <h2 className="text-xs sm:text-sm font-bold text-white truncate max-w-[280px] sm:max-w-lg" title={lectureTitle}>
                {lectureTitle}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Mode switch button */}
            {playerMode !== 'upcoming' && (
              <button
                onClick={() => {
                  if (playerMode === 'embed') {
                    setPlayerMode('hls');
                    initHls(currentStreamUrl);
                  } else {
                    const embedUrl = currentStreamUrl.includes('akamai.net.in') 
                      ? currentStreamUrl 
                      : `https://appx-play.akamai.net.in/video-player?url=${encodeURIComponent(currentStreamUrl)}`;
                    setCurrentStreamUrl(embedUrl);
                    setPlayerMode('embed');
                  }
                }}
                className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1 transition-all"
                title="Switch Player Mode"
              >
                <Layers className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{playerMode === 'embed' ? 'HD Player' : 'Alt Player'}</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-stone-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close lecture"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Canvas Container */}
        <div className="relative w-full aspect-video bg-[#050208] flex items-center justify-center overflow-hidden">
          {/* Buffering Spinner */}
          {loading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/85 z-20 gap-3">
              <div className="relative w-12 h-12">
                <img src="/gb_logo.svg" alt="" className="w-full h-full object-contain animate-pulse" />
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300 tracking-wide">
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                <span>Loading GB STUDY Lecture Stream...</span>
              </div>
            </div>
          )}

          {/* PLAYER MODE: UPCOMING / SCHEDULED */}
          {playerMode === 'upcoming' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-[#140b20] to-[#07030c] p-6 text-center z-10">
              <GBStudyLogo size="lg" className="mb-4" />
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold mb-3">
                <Sparkles className="w-3.5 h-3.5" /> Scheduled Live Lecture
              </div>
              <h3 className="text-base sm:text-xl font-bold text-white max-w-md mb-2">
                {lectureTitle}
              </h3>
              <p className="text-xs text-stone-300 max-w-sm mb-5 leading-relaxed">
                This live session or special lecture stream is managed on our official Telegram community. Join now to get the direct stream link and notification when class starts!
              </p>

              <div className="flex items-center gap-3 flex-wrap justify-center">
                <a
                  href={TELEGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#0088cc] to-[#229ED9] hover:from-[#0095e0] hover:to-[#2cb0f3] text-white text-xs font-bold flex items-center gap-2 shadow-[0_0_20px_rgba(0,136,204,0.4)] transition-all"
                >
                  <Send className="w-4 h-4 fill-white" />
                  <span>Get Live Link on Telegram</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                {pdfUrl && (
                  <button
                    onClick={() => onOpenPdf(lectureTitle + ' - Notes', pdfUrl)}
                    className="px-4 py-2.5 rounded-xl bg-purple-600/20 text-purple-300 hover:bg-purple-600/30 border border-purple-500/30 text-xs font-bold flex items-center gap-1.5"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Download Lecture Notes</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* PLAYER MODE: YOUTUBE EMBED */}
          {playerMode === 'youtube' && (
            <iframe
              src={currentStreamUrl}
              title={lectureTitle}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              allowFullScreen
            />
          )}

          {/* PLAYER MODE: AKAMAI EMBED PLAYER */}
          {playerMode === 'embed' && (
            <iframe
              src={currentStreamUrl}
              title={lectureTitle}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              allowFullScreen
            />
          )}

          {/* PLAYER MODE: NATIVE HLS / HTML5 PLAYER */}
          {playerMode === 'hls' && (
            <>
              <video
                ref={videoRef}
                className="w-full h-full object-contain cursor-pointer"
                onClick={togglePlay}
                onTimeUpdate={handleTimeUpdate}
                onEnded={() => setIsPlaying(false)}
                playsInline
              />

              {/* Player Overlay Controls */}
              <div className="absolute inset-0 flex flex-col justify-between p-3 sm:p-5 bg-gradient-to-t from-black/85 via-transparent to-black/30 pointer-events-none">
                <div />

                {/* Big center play button */}
                {!isPlaying && !loading && (
                  <div className="self-center pointer-events-auto">
                    <button
                      onClick={togglePlay}
                      className="w-16 h-16 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 text-black flex items-center justify-center shadow-[0_0_35px_rgba(245,158,11,0.6)] transform hover:scale-110 active:scale-95 transition-all"
                    >
                      <Play className="w-8 h-8 fill-black ml-1" />
                    </button>
                  </div>
                )}

                {/* Bottom Control Bar */}
                <div className="pointer-events-auto space-y-2 bg-black/40 backdrop-blur-sm p-2 sm:p-3 rounded-2xl border border-white/10">
                  {/* Progress timeline */}
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] font-mono text-amber-300 font-bold">
                      {formatTime(currentTime)}
                    </span>
                    <input
                      type="range"
                      min="0"
                      max={duration || 100}
                      value={currentTime}
                      onChange={handleSeek}
                      className="flex-1 h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
                    />
                    <span className="text-[11px] font-mono text-stone-400">
                      {formatTime(duration)}
                    </span>
                  </div>

                  {/* Buttons Row */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <button
                        onClick={togglePlay}
                        className="p-2 rounded-lg text-white hover:bg-white/10 transition-colors"
                        title={isPlaying ? 'Pause' : 'Play'}
                      >
                        {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                      </button>

                      <button
                        onClick={() => handleSkip(-10)}
                        className="p-2 rounded-lg text-stone-300 hover:text-white hover:bg-white/10 transition-colors"
                        title="Rewind 10s"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleSkip(10)}
                        className="p-2 rounded-lg text-stone-300 hover:text-white hover:bg-white/10 transition-colors"
                        title="Forward 10s"
                      >
                        <RotateCw className="w-4 h-4" />
                      </button>

                      <button
                        onClick={toggleMute}
                        className="p-2 rounded-lg text-stone-300 hover:text-white hover:bg-white/10 transition-colors"
                        title={isMuted ? 'Unmute' : 'Mute'}
                      >
                        {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                    </div>

                    <div className="flex items-center gap-2 relative">
                      {/* Speed & Quality Settings dropdown */}
                      <div className="relative">
                        <button
                          onClick={() => setShowSettings(prev => !prev)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/50 hover:bg-white/10 text-xs font-semibold text-amber-300 border border-amber-500/30"
                        >
                          <Settings className="w-3.5 h-3.5" />
                          <span>{playbackSpeed}x</span>
                        </button>

                        {showSettings && (
                          <div className="absolute bottom-10 right-0 w-44 bg-[#140b20] border border-amber-500/40 rounded-2xl p-2.5 shadow-2xl z-30 space-y-2 text-xs">
                            <div className="text-[10px] font-bold uppercase text-amber-400 px-2">Speed</div>
                            <div className="grid grid-cols-3 gap-1">
                              {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((s) => (
                                <button
                                  key={s}
                                  onClick={() => handleSpeedChange(s)}
                                  className={`py-1 rounded text-center font-bold ${
                                    playbackSpeed === s ? 'bg-amber-500 text-black' : 'hover:bg-white/5 text-stone-300'
                                  }`}
                                >
                                  {s}x
                                </button>
                              ))}
                            </div>

                            {qualities.length > 0 && (
                              <>
                                <div className="text-[10px] font-bold uppercase text-amber-400 px-2 pt-2 border-t border-white/10">Quality</div>
                                <div className="space-y-1">
                                  {qualities.map((q) => (
                                    <button
                                      key={q.quality}
                                      onClick={() => handleQualityChange(q)}
                                      className={`w-full py-1 px-2 rounded text-left font-semibold ${
                                        selectedQuality === q.quality ? 'bg-amber-500 text-black' : 'hover:bg-white/5 text-stone-300'
                                      }`}
                                    >
                                      {q.quality}
                                    </button>
                                  ))}
                                </div>
                              </>
                            )}
                          </div>
                        )}
                      </div>

                      <button
                        onClick={toggleFullscreen}
                        className="p-2 rounded-lg text-stone-300 hover:text-white hover:bg-white/10 transition-colors"
                        title="Fullscreen"
                      >
                        <Maximize className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Bottom Details & Lecture Navigation */}
        <div className="p-4 sm:p-5 overflow-y-auto max-h-[30vh] bg-[#0c0512]">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white leading-snug">
                {lectureTitle}
              </h3>
              <p className="text-xs text-stone-400 mt-1 flex items-center gap-2">
                {publishedDate && (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-amber-400" /> {publishedDate}
                  </span>
                )}
                <span>• GB STUDY Official Lecture</span>
              </p>
            </div>

            <div className="flex items-center gap-2">
              {pdfUrl && (
                <button
                  onClick={() => onOpenPdf(lectureTitle + ' - Notes', pdfUrl)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Download / Open Notes</span>
                </button>
              )}
            </div>
          </div>

          {/* Prev / Next Lecture Navigation */}
          <div className="flex items-center justify-between pt-3 border-t border-white/5 gap-3">
            {prevVideo ? (
              <button
                onClick={() => onSelectVideo(prevVideo)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white text-xs font-medium transition-all"
              >
                <ChevronLeft className="w-4 h-4" />
                <span className="truncate max-w-[140px] sm:max-w-[200px]">Prev: {prevVideo.Title || prevVideo.title}</span>
              </button>
            ) : <div />}

            {nextVideo && (
              <button
                onClick={() => onSelectVideo(nextVideo)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white text-xs font-medium transition-all"
              >
                <span className="truncate max-w-[140px] sm:max-w-[200px]">Next: {nextVideo.Title || nextVideo.title}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
